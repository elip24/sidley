import polars as pl

def make_hash_cols(df:pl.DataFrame,key_cols)-> pl.DataFrame:
    key_cols=set(key_cols)
    cols=[c for c in df.columns if c not in key_cols]
    columns_to_hash=[pl.col(c).cast(pl.Utf8).fill_null("") for c in cols]
    df=df.with_columns(pl.concat_str(columns_to_hash,separator="||").hash(seed=0).alias("hash_cols").cast(pl.Utf8))
    return df

def select_certain_cols_from_list(df:pl.DataFrame,key_cols,search_name)-> pl.DataFrame:
    key_cols = key_cols
    list_columns = [c for c in df.columns if df[c].dtype == pl.List and c==search_name]
    df = df.select(key_cols + list_columns)
    return df

LOCATION_MAP = {
    "Sydney":"Sydney",
    "Palo Alto":"Palo Alto",
    "Los Angeles":"Los Angeles",
    "Baltimore":"Baltimore",
    "San Diego":"San Diego",
    "Brussels":"Brussels",
    "Singapore":"Singapore",
    '"Washington, D.C."':"Washington DC",
    "Century City":"Century City",
    "Geneva":"Geneva",
    "Beijing":"Beijing",
    "Miami":"Miami",
    "Boston":"Boston",
    "Chicago":"Chicago",
    "Munich":"Munich",
    "Seattle":"Seattle",
    "Dallas":"Dallas",
    "London":"London",
    "New York":"New York",
    "Houston":"Houston",
    "San Francisco":"San Francisco",
    "Tokyo":"Tokyo",
    "Hong Kong":"Hong Kong",
    "Dubai":"Dubai",
}
