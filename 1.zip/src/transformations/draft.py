import json
import os

import polars as pl
from datetime import datetime, timezone
from src.transformations.transformations_utils import select_certain_cols_from_list, LOCATION_MAP

root_path=os.getcwd()
file_path_1=os.path.join(root_path,'ingestion_news.json')

with open (file_path_1, 'r', encoding='utf-8') as f:
    data=json.load(f)

df_1=pl.DataFrame(data)
file_path_2 = os.path.join(root_path, 'ingestion_profiles.json')

with open(file_path_1, 'r', encoding='utf-8') as f:
    data = json.load(f)

df_2=pl.DataFrame(data)
df=pl.concat([df_1,df_2])
df=df.unique('id')
df=df.with_columns(pl.lit('sidley').alias('site_page'))
df=df.filter(pl.col('id')=='ce3ab37f-cb5e-490e-9904-c43fc4fbaf0f')
print(df)
def transformation_raw(df):
    df = df.with_columns(pl.lit('sidley').alias('site_page'))
    df = df.with_columns(pl.lit(datetime.now(timezone.utc)).cast(pl.Datetime).alias("syncstartdatetime"))
    df=df.unique('id')
    return df

def transformation_clean_line_location(df):
    df=select_certain_cols_from_list(df,key_cols=['id','site_page'],search_name='locations')
    df=df.explode("locations")
    df = df.with_columns(
        pl.col("locations").str.replace_all(r"[^a-zA-Z0-9\s]", "").alias("locations")
    )
    df = df.with_columns(pl.col('locations').map_elements(lambda x: LOCATION_MAP.get(x, x), return_dtype=pl.Utf8)
                         .alias("locations"))
    df = df.with_row_index("row_order")
    df = df.with_columns(pl.col("row_order").rank(method="dense").over(["site_page", "id"]).cast(pl.Int64)
        .alias("row_order"))
    df = df.with_columns(pl.lit(datetime.now(timezone.utc)).cast(pl.Datetime).alias("syncstartdatetime"))
    return df

def transformation_clean_line_phones(df):
    df=select_certain_cols_from_list(df,key_cols=['id','site_page'],search_name='phones')
    df=df.explode('phones')
    df=df.filter(pl.col('phones').str.contains(r"^[0-9\+\s]+$"))
    df = df.with_columns(pl.col("phones").str.replace_all(" ", "-"))
    df = df.with_columns(pl.lit(datetime.now(timezone.utc)).cast(pl.Datetime).alias("syncstartdatetime"))
    return df


df_1=transformation_clean_line_phones(df)
df=transformation_clean_line_location(df)
missing_ids = df.join(df_1, on="id", how="anti")
missing_ids.write_csv('mising_ids.csv')
