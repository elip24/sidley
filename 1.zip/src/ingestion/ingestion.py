import json
from asyncio import Semaphore
from datetime import datetime
import httpx
import asyncio
from concurrency_utils import process_with_semaphore
from get_url_requests import get_url_requests
from profiles_only import profiles_only

MAX_CONCURRENT_REQUESTS=5

async def main_news():
    limits = httpx.Limits(max_connections=20, max_keepalive_connections=20)
    async with httpx.AsyncClient(timeout=30, limits=limits) as client:
        # semáforo exclusivo sólo para get_url_requests
        sem_get = Semaphore(1)
        async with sem_get:
            deduped_urls, all_meta = await get_url_requests(client)
        semaphore = Semaphore(MAX_CONCURRENT_REQUESTS)
        tasks = [
            process_with_semaphore(
                client=client,
                start_url=meta["url"],
                semaphore=semaphore,
                extractor_function=profiles_only,
                meta=meta,
            )
            for meta in all_meta
        ]
        results = []
        for coro in asyncio.as_completed(tasks):
            try:
                rec = await coro
                if rec:
                    results.append(rec)
            except Exception as e:
                print(f"Failed to extract news: {e}")
    return results

def ingestion():
    all_news=asyncio.run(main_news())
    with open("../transformations/ingestion_profiles.json", "w", encoding="utf-8") as f:
        json.dump(all_news, f, ensure_ascii=False, default=str, indent=2)

    return all_news

ingestion()

