
prefix='https://www.sidley.com/'
url_token='https://www.sidley.com/coveo/rest/token'
API_URL='https://www.sidley.com/en/api/sitecore/people/search'

headers={
        "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36 Edg/139.0.0.0",
        "Accept-Language": "es,es-ES;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6,es-AR;q=0.5",
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Priority": "u=1, i",
        "Cache-Control": "max-age=0",
        "Pragma": "no-cache",
        "Upgrade-Insecure-Requests": "1",
        "sec-ch-ua-platform":"Windows",
        "x-requested-with":"XMLHttpRequest",
        "scheme":"https",
        "Content-type":"application/json; charset=UTF-8",
}

def make_payload(page: int) -> dict:
    take = 100
    skip = page * take

    return {
        "CurrentViewID": "83e3dcaa-1264-4226-8ee6-380c20e95bea",

        "InitialPageSize": skip,
        "ReloadFilters": False,
        "ManagementCommitteeOnly": False,
        "MultipleResultLabel": "Results",
        "OfficeFilters": [],
        "PracticeFilters": [],
        "SchoolFilters": [],
        "SingleResultLabel": "Result",
        "MultipleResultLabel": "Results",
        "Skip": skip,
        "Take": take,
    }