import asyncio
import re
from bs4 import BeautifulSoup
from page_configurations import headers
import httpx

def all_values_in_header(soup: BeautifulSoup,header_search):
    """Added the first head_name because sometimes we have white space at the beggining of the header"""
    head_name = re.compile(rf'^[\s\u00a0]*{re.escape(header_search)}[\s\u00a0]*$', re.I)
    """The regex is to get all the headers"""
    head=soup.find(re.compile(r'^h[1-6]$'),string=head_name)
    if not head:
        return []
    related_ul=head.find_next_sibling('ul')
    if not related_ul:
        related_ul = head.find_parent("div").find('ul')
    different_values_of_list=related_ul.find_all('li',recursive=False)
    items = [" ".join(item.stripped_strings) for item in different_values_of_list]
    return items

def find_locations_and_phones(soup: BeautifulSoup,header_search):
    """Added the first head_name because sometimes we have white space at the beggining of the header"""
    head_name = re.compile(rf'^[\s\u00a0]*{re.escape(header_search)}[\s\u00a0]*$', re.I)
    """The regex is to get all the headers"""
    head = soup.find(re.compile(r'^h[1-6]$'), string=head_name)
    if not head:
        return []
    related_ul = head.find_next_sibling('ul')
    if not related_ul:
        related_ul = head.find_parent("div").find('ul')
    different_values_of_list = related_ul.find_all('li', recursive=False)
    locations = []
    phones = []
    for item in different_values_of_list:
        a = item.find('a', href=True)
        if a['href'].startswith('mailto:') or 'email' in a.get('class'):
            continue
        phones_i=a['href'].removeprefix("tel:").strip()
        phones.append(phones_i)
        locations_i=a.get("data-siteimprove-title") or ""
        locations.append(locations_i)
    return phones,locations

async def profiles_only(client: httpx.AsyncClient,start_url:str,meta):
    r=await client.get(url=start_url,
                 timeout=30,
                 headers=headers)
    r.raise_for_status()
    soup = BeautifulSoup(r.content, 'html.parser')
    capabilities=all_values_in_header(soup,'Capabilities')
    phones, locations=find_locations_and_phones(soup, 'Contact')
    education=all_values_in_header(soup,'Education')
    all_profiles={
        'locations':locations,
        'phones':phones,
        'capabilities':capabilities,
        'education':education,
    }
    if meta:
        all_profiles.update(meta)
    await asyncio.sleep(3)

    return all_profiles


import asyncio
import re
from bs4 import BeautifulSoup
from page_configurations import headers
import httpx

def all_values_in_header(soup: BeautifulSoup,header_search):
    """Added the first head_name because sometimes we have white space at the beggining of the header"""
    head_name = re.compile(rf'^[\s\u00a0]*{re.escape(header_search)}[\s\u00a0]*$', re.I)
    """The regex is to get all the headers"""
    head=soup.find(re.compile(r'^h[1-6]$'),string=head_name)
    if not head:
        return []
    related_ul=head.find_next_sibling('ul')
    if not related_ul:
        related_ul = head.find_parent("div").find('ul')
    different_values_of_list=related_ul.find_all('li',recursive=False)
    items = [" ".join(item.stripped_strings) for item in different_values_of_list]
    return items

def find_locations_and_phones(soup: BeautifulSoup,header_search):
    """Added the first head_name because sometimes we have white space at the beggining of the header"""
    head_name = re.compile(rf'^[\s\u00a0]*{re.escape(header_search)}[\s\u00a0]*$', re.I)
    """The regex is to get all the headers"""
    head = soup.find('ul', class_='people-hero-contact-list')
    if not head:
        return [],[]
    different_values_of_list = head.find_all('li', recursive=False)
    locations = []
    phones = []
    for item in different_values_of_list:
        loc_a = item.find_all("a", class_="location-name")
        if loc_a:
            locations=[loc.get_text(strip=True) for loc in loc_a]
        phone_a=item.find_all('a', href=re.compile(r"^tel:"))
        if phone_a:
            phones=[phone.get_text(strip=True) for phone in phone_a]
    return phones,locations

async def profiles_only(client: httpx.AsyncClient,start_url:str,meta):
    r=await client.get(url=start_url,
                 timeout=30,
                 headers=headers)
    r.raise_for_status()
    soup = BeautifulSoup(r.content, 'html.parser')
    capabilities=all_values_in_header(soup,'Capabilities')
    phones, locations=find_locations_and_phones(soup, 'Contact')
    education=all_values_in_header(soup,'Education')
    all_profiles={
        'locations':locations,
        'phones':phones,
        'capabilities':capabilities,
        'education':education,
    }
    if meta:
        all_profiles.update(meta)
    await asyncio.sleep(10)

    return all_profiles