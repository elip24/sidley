import html
import re
from datetime import datetime, timezone
from typing import Iterable, Tuple, List, Dict, Set
from urllib.parse import urljoin

import unicodedata

from .page_configurations import prefix


def get_url(row: dict)->str:
    url=row.get("Url")
    if isinstance(url, str) and url.strip():
        return urljoin(prefix, url)

def get_urls_and_attributes(response):
    results = [
        {
            "id":row["ID"],
            "Name": row["Name"],
            "url": get_url(row),
            "position": row["AttorneyLevelTitle"],
            "email":row["BusinessEmail"],
        }
        for row in response
    ]
    return results
