import asyncio
import json
import math
from datetime import datetime

import httpx
from typing import AsyncIterator, Dict, Any, List
from src.ingestion.page_configurations import make_payload, API_URL, prefix, url_token, headers
from src.ingestion.parse_api import get_urls_and_attributes
import csv


async def warm_cookies(client: httpx.AsyncClient):
    r =await client.get('https://www.sidley.com/en/us/people', timeout=30, headers=headers)
    r.raise_for_status()


async def post_with_payload(client,page:int):
    payload = make_payload(page=page)
    r = await client.post(API_URL,json=payload,timeout=30, headers=headers)
    return r

def parse_results(r):
    data=r.json()
    grid_data=data.get("GridData",[])
    amount = data.get("ResultCount")
    return grid_data,amount


async def get_url_requests(client):
    await warm_cookies(client)
    deduped_urls = set()
    all_urls=[]
    all_meta = []
    data= {}
    page=1
    resp1 = await post_with_payload(client, page)
    first_items, total = parse_results(resp1)
    max_page = max(1, math.ceil(total / 100))
    for item in get_urls_and_attributes(first_items):
        url = item.get("url")
        if url and url not in deduped_urls:
            all_urls.append(url)
            deduped_urls.add(url)
        all_meta.append(item)


    await asyncio.sleep(5)
    for p in range(2, max_page + 1):
        r = await post_with_payload(client, page=p)
        items, _ = parse_results(r)
        for item in get_urls_and_attributes(items):
            url = item.get("url")
            if url and url not in deduped_urls:
                all_urls.append(url)
                deduped_urls.add(url)
            all_meta.append(item)
        await asyncio.sleep(10)
    print(deduped_urls)
    with open('output.csv','w',newline='') as csvfile:
        writer = csv.writer(csvfile)
        for item in deduped_urls:
            writer.writerow([item])
    return deduped_urls, all_meta
