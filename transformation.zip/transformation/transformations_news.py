from datetime import datetime, timezone, date
from pathlib import Path
import os
import json
import polars as pl

from src.transformation.transformations_ml import extract_people_from_text
from src.transformation.transformation_util import transform_array_into_list, make_hash_col, clean_text_for_ml, \
    normalize_person_name


def transformation_news(all_news:dict)->pl.DataFrame:
    df = pl.DataFrame(all_news)
    df = df.unique('permanentid')
    df=df.with_columns(
        pl.col("datePublished").str.strptime(pl.Date,format="%B %d, %Y",strict=False)
        .dt.strftime("%Y-%m-%d").cast(date)
        .alias("datePublished")
    )
    df=transform_array_into_list(df,"lawyer_link")
    df = transform_array_into_list(df, "lawyer_names")
    df=df.with_columns(pl.from_epoch("contentdate", time_unit="ms").alias("content_date_watermark"))
    df=df.with_columns(pl.col("permanentid").alias('id'))
    df=df.unique('id')
    df=df.filter(pl.col('id').is_not_null())
    df=df.with_columns(pl.lit('lw').alias('site_page'))
    df=df.with_columns(pl.lit(datetime.now(timezone.utc)).cast(pl.Datetime).alias("syncstartdatetime"))
    df=df.drop(pl.col(['permanentid','contentdate']))
    df = make_hash_col(df, key_cols=['id','url','site_page'])
    return df

def transformation_news_raw(all_news:dict)->pl.DataFrame:
    df = pl.DataFrame(all_news)
    df=df.unique('permanentid')
    df = df.with_columns(pl.lit(datetime.now(timezone.utc)).cast(pl.Datetime).alias("syncstartdatetime"))
    return df

base_cols = ["id", "site_page", "datePublished", "headline", "url", "syncstartdatetime"]

def transformations_news_per_person(df):
    df = clean_text_for_ml(df, column_name='text')
    df = extract_people_from_text(df, text_col='clean_text', out_names=("persons_ml", "score_ml"), min_conf=0)
    df = df.with_columns(pl.col("persons_ml").list
                         .eval(pl.element().map_elements(normalize_person_name, return_dtype=pl.Utf8))
                         .alias("persons_ml_norm")
    )
    link_rows = (
        df.select(base_cols + ["lawyer_link"])
        .explode("lawyer_link")
        .filter(pl.col("lawyer_link").is_not_null())
        .with_columns([
            pl.lit("link_html").alias("match_source"),
            pl.lit(1.0).alias("score_ml"),
            pl.lit(None, dtype=pl.Utf8).alias("persons_ml"),
            pl.lit(None, dtype=pl.Utf8).alias("persons_ml_norm"),
        ])
    )
    ml_rows = (
        df.select(base_cols + ["persons_ml", "persons_ml_norm", "score_ml"])
        .explode(["persons_ml", "persons_ml_norm", "score_ml"])
        .filter(pl.col("persons_ml").is_not_null())
        .with_columns([
            pl.lit(None, dtype=pl.Utf8).alias("lawyer_link"),
            pl.lit("body_ml").alias("match_source"),
        ])
        .select(base_cols + ["lawyer_link","match_source","score_ml","persons_ml","persons_ml_norm"])
    )
    df = pl.concat([link_rows, ml_rows], how="vertical").rename({"id": "article_id"})
    return df


def transformations(all_news:dict):
    df=transformation_news(all_news)
    df_raw=transformation_news_raw(all_news)
    df_line = transformations_news_per_person(df)

    return df, df_raw, df_line

