import asyncio
import json
import math
from datetime import datetime

import httpx
from typing import AsyncIterator, Dict, Any, List
from src.ingestion.page_configurations import make_payload, API_URL, prefix, url_token, headers
from src.ingestion.parse_api import get_urls_and_attributes


async def warm_cookies(client: httpx.AsyncClient):
    r =await client.get('https://www.sidley.com/en/newslanding', timeout=30, headers=headers)
    r.raise_for_status()


async def post_with_payload(client,page:int):
    payload = make_payload(page=page)
    r = await client.post(
        API_URL,
        json=payload,
        timeout=30, headers=headers)
    return r

def parse_results(r):
    data=r.json()
    data=data.get("GridData",[])
    return data

async def get_url_requests(client):
    await warm_cookies(client)
    deduped_urls = set()
    all_meta = []
    page=0
    max_count=995
    max_pages=math.ceil(max_count/12)
    for page in range(0,max_pages+1):
        r=await post_with_payload(client,page=page)
        raw_items = parse_results(r)
        data = get_urls_and_attributes(raw_items)
        for item in data:
            url=item.get("url")
            deduped_urls.add(url)
            all_meta.append(item)
            print(url)
        await asyncio.sleep(5)
    return deduped_urls,all_meta
