import asyncio
import re
from bs4 import BeautifulSoup
from page_configurations import headers
import httpx

def all_values_in_header(soup: BeautifulSoup,header_search):
    """Added the first head_name because sometimes we have white space at the beggining of the header"""
    head_name = re.compile(rf'^[\s\u00a0]*{re.escape(header_search)}[\s\u00a0]*$', re.I)
    """The regex is to get all the headers"""
    head=soup.find(re.compile(r'^h[1-6]$'),string=head_name)
    if not head:
        return []
    related_ul=head.find_next_sibling('ul')
    if not related_ul:
        related_ul = head.find_parent("header").find_next_sibling("ul", recursive=False)
    different_values_of_list=related_ul.find_all('li',recursive=False)
    items = [" ".join(item.stripped_strings) for item in different_values_of_list]
    return items

def get_article_text(soup: BeautifulSoup) -> str:
    section = soup.find("div", class_="rich-text-content")
    if not section:
        return ""
    # fallback: busca <p>, si no hay, usa los .stripped_strings
    paragraphs = section.find_all("p")
    if paragraphs:
        return "\n\n".join(p.get_text(" ", strip=True) for p in paragraphs)
    else:
        return "\n\n".join(section.stripped_strings)

def extract_related_professionals(soup: BeautifulSoup, header_search: str):
    head_name = re.compile(rf'^[\s\u00a0]*{re.escape(header_search)}[\s\u00a0]*$', re.I)
    h = soup.find(re.compile(r'^h[1-6]$'), string=head_name)
    if not h:
        return []
    header_tag = h.find_parent("header")
    ul = header_tag.find_next("ul", class_="contact-cards")
    if not ul:
        return []
    persons_name=[]
    persons_link=[]
    for li in ul.find_all("li", class_="contact-card", recursive=False):
        name_tag = li.select_one(".contact-name a")
        if name_tag:
            persons_name.append(name_tag.get_text(strip=True))
            persons_link.append(name_tag['href'])
    return persons_name,persons_link



with httpx.Client(headers=headers) as client:
    r=client.get(url='https://www.sidley.com/en/newslanding/newsannouncements/2024/08/sidley-represents-exiger-in-its-acquisition-of-xsb',
                         timeout=30,
                         headers=headers)
    r.raise_for_status()
    soup = BeautifulSoup(r.content, 'html.parser')
    capabilities=all_values_in_header(soup,'Related Capabilities')
    text=get_article_text(soup)
    print(text)
    all_news={
                    "text": text,
                    "capabilities": capabilities,
            }


