import html
import re
from datetime import datetime, timezone
from typing import Iterable, Tuple, List, Dict, Set
from urllib.parse import urljoin

import unicodedata

from .page_configurations import prefix


def parse_publicationdate(s:str) ->datetime:
    s = html.unescape(s or "")
    s = unicodedata.normalize("NFKC", s)
    s = re.sub(r'\s+', ' ', s).strip()
    try:
        publication_date=datetime.strptime(s, "%B %d, %Y").date()
    except ValueError:
        # Fallback solo para casos sin día como "October/November 2023"
        m = re.match(r"^([A-Za-z]+)(?:/[A-Za-z]+)?\s+(\d{4})$", s)
        if m:
            month, year = m.groups()
            try:
                # Tomar el primer mes del rango, día 1
                return datetime.strptime(f"{month} 1, {year}", "%B %d, %Y").date()
            except ValueError:
                # Intentar con abreviatura de mes
                return datetime.strptime(f"{month} 1, {year}", "%b %d, %Y").date()
        # si no entra en el patrón raro, re-lanzar el error
        raise
    return publication_date


def get_url(row: dict)->str:
    navigation=row.get("NavigateLink")
    url = navigation.get("Url")
    if isinstance(url, str) and url.strip():
        return urljoin(prefix, url)

def get_urls_and_attributes(response):
    results = [
        {
            "id":row["ID"],
            "headline": row["Title"],
            "url": get_url(row),
            "datePublished": parse_publicationdate(row["DisplayDate"]),
            "articleSection":row["ContentType"],
        }
        for row in response
    ]
    return results
