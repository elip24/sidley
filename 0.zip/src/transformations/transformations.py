import html
import json
import os
from datetime import datetime, timezone

import polars as pl
from pathlib import Path

import unicodedata
from polars import lit

from transformations_ml import extract_people_from_text
from transformations_utils import get_from_string_to_datetime, transform_array_into_list, make_hash_col, \
    clean_text_for_ml, normalize_person_name


def transformations_news(all_news:dict)->pl.DataFrame:
    df = pl.DataFrame(all_news)
    df=df.unique(['id'])
    df=transform_array_into_list(df,"capabilities")
    df = transform_array_into_list(df, "lawyer_link")
    df = transform_array_into_list(df, "lawyer_names")
    df = df.with_columns(pl.lit('sidley').alias('site_page'))
    df = make_hash_col(df,key_cols=['id','site_page','url'])
    df = df.with_columns(pl.lit(datetime.now(timezone.utc)).cast(pl.Datetime).alias("syncstartdatetime"))
    return df

def transformation_news_raw(all_news:dict)->pl.DataFrame:
    df = pl.DataFrame(all_news)
    df=df.unique('id')
    df = df.with_columns(pl.lit(datetime.now(timezone.utc)).cast(pl.Datetime).alias("syncstartdatetime"))
    return df


base_cols = ["id", "site_page", "datePublished", "headline", "url", "syncstartdatetime"]
def transformations_news_per_person(df):
    df = df.with_columns(
        pl.col("lawyer_link").list.eval(
            pl.element().map_elements(
                lambda s: unicodedata.normalize("NFKC", html.unescape(s)) if s is not None else s,
                return_dtype=pl.Utf8
            )
        ).alias("lawyer_link"))
    df = clean_text_for_ml(df, column_name='text')
    df = extract_people_from_text(df, text_col='clean_text', out_names=("persons_ml", "score_ml"), min_conf=0)
    df = df.with_columns(pl.col("persons_ml").list
                         .eval(pl.element().map_elements(normalize_person_name, return_dtype=pl.Utf8))
                         .alias("persons_ml_norm")
    )
    link_rows = (
        df.select(base_cols + ["lawyer_link"])
        .explode("lawyer_link")
        .filter(pl.col("lawyer_link").is_not_null())
        .with_columns([
            pl.lit("link_html").alias("match_source"),
            pl.lit(1.0).alias("score_ml"),
            pl.lit(None, dtype=pl.Utf8).alias("persons_ml"),
            pl.lit(None, dtype=pl.Utf8).alias("persons_ml_norm"),
        ])
    )
    ml_rows = (
        df.select(base_cols + ["persons_ml", "persons_ml_norm", "score_ml"])
        .explode(["persons_ml", "persons_ml_norm", "score_ml"])
        .filter(pl.col("persons_ml").is_not_null())
        .with_columns([
            pl.lit(None, dtype=pl.Utf8).alias("lawyer_link"),
            pl.lit("body_ml").alias("match_source"),
        ])
        .select(base_cols + ["lawyer_link","match_source","score_ml","persons_ml","persons_ml_norm"])
    )
    df = pl.concat([link_rows, ml_rows], how="vertical").rename({"id": "article_id"})
    return df

def transformations(all_news:dict):
    df=transformations_news(all_news)
    df_raw=transformation_news_raw(all_news)
    df_line = transformations_news_per_person(df)
    return df,df_raw,df_line

ROOTPATH=os.getcwd()
file_path=os.path.join(ROOTPATH,'ingestion_news.json')
with open(file_path, 'r', encoding='utf-8') as f:
    all_news = json.load(f)
df,df_raw,df_line=transformations(all_news)
df.write_parquet('df.parquet')
df_line.write_parquet('df_line.parquet')
df_raw.write_parquet('df_raw.parquet')

