import polars as pl

df=pl.read_parquet('df.parquet')
print(df)