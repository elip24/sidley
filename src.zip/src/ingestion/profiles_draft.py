import asyncio
import re
import  httpx
from bs4 import BeautifulSoup
from src.ingestion.page_configurations import header


def all_values_in_header(soup: BeautifulSoup,header_search):
    """Added the first head_name because sometimes we have white space at the beggining of the header"""
    head_name = re.compile(rf'^[\s\u00a0]*{re.escape(header_search)}[\s\u00a0]*$', re.I)
    """The regex is to get all the headers"""
    head=soup.find(re.compile(r'^h[1-6]$'),string=head_name)
    if not head:
        return []
    related_ul=head.find_next_sibling('ul')
    if not related_ul:
        related_ul = head.parent.find("ul", recursive=False)
    different_values_of_list=related_ul.find_all('li',recursive=False)
    items = [" ".join(item.stripped_strings) for item in different_values_of_list]
    return items


start_url='https://www.kirkland.com/lawyers/b/bacon-douglas-e-pc'
r=httpx.get(url=start_url,timeout=30,headers=header)
r.raise_for_status()
soup = BeautifulSoup(r.content, 'html.parser')
locations = [a.get_text(strip=True) for a in soup.select(".profile-heading__location-link")]
phones    = [a.get_text(strip=True) for a in soup.select(".profile-heading__location-phone")]
education=all_values_in_header(soup,'Education')
practices=all_values_in_header(soup,'Practices')
if practices==[]:  # empty list or None
    specialty = soup.find("a", class_="profile-heading__specialty")
    if specialty:
        practices = [specialty.get_text(strip=True)]
    else:
        practices = []
print(practices)

all_profiles={
        'locations':locations,
        'phones':phones,
        'education':education,
        'practices':practices,
}

