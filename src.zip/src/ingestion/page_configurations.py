
prefix='https://www.kirkland.com/'
API_URL='https://www.kirkland.com/api/sitecore/ProfessionalsApi/Lawyers?letter=A'
header={
        "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36 Edg/139.0.0.0",
        "Accept-Language": "es,es-ES;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6,es-AR;q=0.5",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Priority": "u=0, i",
        "Cache-Control": "max-age=0",
        "Pragma": "no-cache",
        "Upgrade-Insecure-Requests": "1",
}

def make_payload(letter:str,page:int)->dict:
    payload=  {
    "letter":letter,
    "page": page
    }
    return payload