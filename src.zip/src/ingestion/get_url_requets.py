import asyncio
import math
from datetime import datetime

import httpx
from typing import AsyncIterator, Dict, Any, List
from src.ingestion.page_configurations import make_payload, header, API_URL, prefix
from src.ingestion.parse_api import get_urls_and_dates


async def warm_cookies(client: httpx.AsyncClient):
    r =await client.get('https://www.kirkland.com/lawyers', timeout=30, headers=header)
    r.raise_for_status()

async def post_with_payload(client,letter:str,page:int):
    payload = make_payload(letter=letter,page=page)
    r = await client.post(
        API_URL,
        json=payload,
        timeout=30, headers=header)
    return r

def parse_results(r):
    data=r.json()
    amount = data.get("TotalSearchResults")
    data=data.get("Results",[])
    return data,amount

async def get_url_requests(client,):
    await warm_cookies(client)
    deduped_urls = set()
    all_meta = []
    stop=False
    page=0
    # ASCII value of A=65 and Z=90
    for i in range(65, 91):
        letter=chr(i)
        print(letter)
        r = await post_with_payload(client, letter=letter, page=page)
        raw_items, amount = parse_results(r)
        total = int(amount or 0)
        max_page = math.ceil(total / 9) #Maximum value per page

        for page in range(0,max_page):
            r=await post_with_payload(client,letter=letter,page=page)
            raw_items,amount=parse_results(r)
            data=get_urls_and_dates(raw_items)
            for item in data:
                url=item.get('url')
                deduped_urls.add(url)
                all_meta.append(item)
        await asyncio.sleep(1)
    await asyncio.sleep(1)

    return deduped_urls, all_meta