import re
from datetime import datetime, timezone
from typing import Iterable, Tuple, List, Dict, Set
from urllib.parse import urljoin
from .page_configurations import prefix


def parse_publicationdate(s:str) ->datetime:
    publication_date=datetime.strptime(s, "%d %B %Y").date()
    return publication_date


def build_url(path: str) -> str:
    return urljoin(prefix, path)

def get_urls_and_dates(response):
    results = [
        {
            "id":row["Url"],
            "Name": row["Name"],
            "Position":row["Position"],
            "Email":row["Email"],
            "url": build_url(row["Url"]),
        }
        for row in response
    ]
    return results
