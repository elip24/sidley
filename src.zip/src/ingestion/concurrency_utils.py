from asyncio import Semaphore

async def process_with_semaphore(client,start_url: str, semaphore: Semaphore, extractor_function,meta) -> dict:
    async with semaphore:
        print(f"Processing: {start_url}")
        try:
            data = await extractor_function(client,start_url,meta=meta)
            return data
        except Exception as e:
            print(f" Exception: {e}")
            return None
