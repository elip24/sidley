import json
from asyncio import Semaphore
from datetime import datetime

import httpx
import asyncio

from src.config.settings import client
from src.ingestion.concurrency_utils import process_with_semaphore
from src.ingestion.date_functions import get_last_startdate
from src.ingestion.get_url_requets import get_url_requests
from src.ingestion.profiles_only import profiles_only
import json

MAX_CONCURRENT_REQUESTS=1

async def main_news():
    async with httpx.AsyncClient(timeout=30) as client:
        deduped_urls, all_meta = await get_url_requests(client)
        semaphore = Semaphore(MAX_CONCURRENT_REQUESTS)
        tasks = [
            process_with_semaphore(
                client=client,
                start_url=meta["url"],
                semaphore=semaphore,
                extractor_function=profiles_only,
                meta=meta,
            )
            for meta in all_meta
        ]
        results = []
        for coro in asyncio.as_completed(tasks):
            try:
                rec = await coro
                if rec:
                    results.append(rec)
            except Exception as e:
                print(f"Failed to extract news: {e}")
    return results

def ingestion():
    all_profiles=asyncio.run(main_news())
    return all_profiles

all_profiles=ingestion()
with open('../transformations/profiles.json', 'w', encoding='utf-8') as f:
    json.dump(all_profiles, f, ensure_ascii=False, indent=4)
