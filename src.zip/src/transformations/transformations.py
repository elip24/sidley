import os
from datetime import datetime, timezone

import polars as pl

from src.transformations.transformations_utils import get_ids_attribute, make_hash_cols, select_certain_cols_from_list, \
    LOCATION_MAP


def transformation_raw():
    ROOT_PATH = os.getcwd()
    path_file = os.path.join(ROOT_PATH, 'profiles.json')
    df = pl.read_json(path_file)
    df = df.with_columns(pl.lit(datetime.now(timezone.utc)).cast(pl.Datetime).alias("syncstartdatetime"))
    return df

def transformation_all_header():
    ROOT_PATH = os.getcwd()
    path_file = os.path.join(ROOT_PATH, 'profiles.json')
    df = pl.read_json(path_file)
    df = get_ids_attribute(df, 'id',site_page='kirkland')
    df.unique('id')
    return df

def transformation_header():
    df=transformation_all_header()
    df = df.select(pl.exclude(pl.List))
    df = make_hash_cols(df, key_cols=['id', 'url','raw_id'])
    df = df.with_columns(pl.lit(datetime.now(timezone.utc)).cast(pl.Datetime).alias("syncstartdatetime"))
    return df

def transformation_clean_line_location(df):
    # We are using map element because when we use search it reorders the df and we want to keep it as it came since
    # That locations is associated with that phone
    df=select_certain_cols_from_list(df,key_cols=['id','raw_id','site_page'],search_name='locations')
    df=df.explode('locations')
    df = df.with_columns(
        pl.col("locations").str.replace_all(r"[^a-zA-Z0-9\s]", "").alias("locations")
    )
    df=df.with_columns(pl.col('locations').map_elements(lambda x: LOCATION_MAP.get(x, x), return_dtype=pl.Utf8)
                       .alias("locations"))
    df = df.with_columns(pl.lit(datetime.now(timezone.utc)).cast(pl.Datetime).alias("syncstartdatetime"))
    return df

def transformation_clean_line_phones(df):
    df=select_certain_cols_from_list(df,key_cols=['id','raw_id','site_page'],search_name='phones')
    df=df.explode('phones')
    df=df.with_columns(pl.col('phones').str.replace_all(' ','-').alias('phones'))
    df = df.with_columns(pl.lit(datetime.now(timezone.utc)).cast(pl.Datetime).alias("syncstartdatetime"))
    return df

def transformation_clean_line_education(df):
    df=select_certain_cols_from_list(df,key_cols=['id','raw_id','site_page'],search_name='education')
    df=df.explode('education')
    df=df.with_columns(pl.col('education')
                       .str.to_lowercase()
                       .str.replace_all(r"\.", "")
                       .str.contains('jd').alias('has_jd'))
    df = df.with_columns(
        pl.when(pl.col("has_jd")==True)
        .then(
            pl.col("education")
            .str.extract(r"\b((?:19|20)\d{2})\b", 1)  # capture a 4-digit year
            .cast(pl.Int32)
        )
        .otherwise(None)
        .alias("jd_year")
    )
    df = df.with_columns(pl.lit(datetime.now(timezone.utc)).cast(pl.Datetime).alias("syncstartdatetime"))
    return df

def transformation_clean_line_practices(df):
    df=select_certain_cols_from_list(df,key_cols=['id','raw_id','site_page'],search_name='practices')
    df=df.explode('practices')
    df = df.with_columns(pl.lit(datetime.now(timezone.utc)).cast(pl.Datetime).alias("syncstartdatetime"))
    return df

def transformations():
    df = transformation_raw()
    df.write_parquet('transformed_raw.parquet')
    df_1=transformation_all_header()
    df = transformation_clean_line_location(df_1)
    df = df.with_row_index("row_order")
    df.write_parquet('profiles_locations.parquet')

transformations()