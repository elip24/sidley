import os
from datetime import datetime, timezone
import polars as pl


def get_ids_attribute(df:pl.DataFrame,id_element:str,site_page)-> pl.DataFrame:
    df=df.with_columns(pl.col(f'{id_element}').alias('raw_id'))
    df=df.with_columns(pl.col(f'{id_element}').str.split(by='/').list.last().alias('id'))
    df = df.with_columns(pl.lit(f'{site_page}').alias('site_page'))
    return df

def make_hash_cols(df:pl.DataFrame,key_cols)-> pl.DataFrame:
    key_cols=set(key_cols)
    cols=[c for c in df.columns if c not in key_cols]
    columns_to_hash=[pl.col(c).cast(pl.Utf8).fill_null("") for c in cols]
    df=df.with_columns(pl.concat_str(columns_to_hash,separator="||").hash(seed=0).alias("hash_cols").cast(pl.Utf8))
    return df

def select_certain_cols_from_list(df:pl.DataFrame,key_cols,search_name)-> pl.DataFrame:
    key_cols = key_cols
    list_columns = [c for c in df.columns if df[c].dtype == pl.List and c==search_name]
    df = df.select(key_cols + list_columns)
    return df

LOCATION_MAP = {
"Brussels":"Brussels",
"New York":"New York",
"Beijing":"Beijing",
"Paris":"Paris",
"Bay Area  San Francisco":"San Francisco",
"Hong Kong":"Hong Kong",
"Chicago":"Chicago",
"Boston":"Boston",
"Washington DC":"Washington DC",
"Munich":"Munich",
"Salt Lake City":"Salt Lake City",
"London":"London",
"Bay Area  Palo Alto":"Palo Alto",
"Miami":"Miami",
"Dallas":"Dallas",
"Austin":"Austin",
"Houston":"Houston",
"Los Angeles":"Los Angeles",
"Riyadh":"Riyadh",
"Frankfurt":"Frankfurt",
"Shanghai":"Shanghai",
"Philadelphia":"Philadelphia",
}